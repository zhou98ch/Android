package com.example.sensor;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;

import com.google.android.material.snackbar.Snackbar;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.provider.Settings;
import android.util.Log;
import android.view.View;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.example.sensor.databinding.ActivityMainBinding;

import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements SensorEventListener, LocationListener {

    private AppBarConfiguration appBarConfiguration;
    private ActivityMainBinding binding;

    //parameter for sensor
    // 1/10s
    final private int samplingPeriod=10000;
    private SensorManager sensorManager;
    private Sensor sensor1,sensor2;
    private boolean sensorListenerRegistered=false;
    private TextView tvX,tvY,tvZ;

    //parameter for location
    static private final int MY_PERMISSION_REQUEST_FINE_LOCATION=1;
    static private final String TAG=MainActivity.class.getCanonicalName();
    //ms
    static private final long minTime=1000;
    //m
    static private final float minDistance=10;
    private LocationManager locationManager;
    private TextView tvLon,tvLat;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setSupportActionBar(binding.toolbar);

        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main);
        appBarConfiguration = new AppBarConfiguration.Builder(navController.getGraph()).build();
        NavigationUI.setupActionBarWithNavController(this, navController, appBarConfiguration);

        binding.fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }

        });
        //Sensor(accelerometer and gyroscope) Managerment
        tvX=findViewById(R.id.textViewX);
        tvY=findViewById(R.id.textViewY);
        tvZ=findViewById(R.id.textViewZ);

        sensorManager =(SensorManager) getSystemService(Context.SENSOR_SERVICE);
        sensor1 = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        sensor2 = sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE);

        //Location Managerment
        tvLon=findViewById(R.id.longitute);
        tvLat=findViewById(R.id.latitude);
        locationManager=(LocationManager) getSystemService(Context.LOCATION_SERVICE);
    }

    @Override
    protected void onStart(){
        super.onStart();
        //for sensor
        if(sensorManager.registerListener(this,sensor1,samplingPeriod)){
            sensorListenerRegistered=true;
        }else{

        }
        //for location
        if (!locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            enableLocationSettings();
        } else {
            if (Build.VERSION.SDK_INT >= 23 &&
                    ContextCompat.checkSelfPermission(this,
                            Manifest.permission.ACCESS_FINE_LOCATION) !=
                            PackageManager.PERMISSION_GRANTED) {
                requestPermissions();
            }

            else{
                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, minTime, minDistance, this);
            }
        }


    }

    @Override
    public void onStop() {
        super.onStop();
        Log.i(TAG,"stopped");

        if(sensorListenerRegistered){
            sensorManager.unregisterListener(this);
        }

        locationManager.removeUpdates(this);
    }
//Permissions not relevant for task2
    private void enableLocationSettings() {
        new AlertDialog.Builder(this)
                .setTitle("Enable GPS")
                .setMessage("GPS currentlt disabled. Do you want to enable GPS?")
                .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Intent settingsIntent=new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                    }
                })
                .setNegativeButton(android.R.string.no,null)
                .setIcon(android.R.drawable.ic_dialog_alert)
                .show();
    }
    //Permissions not relevant for task2

    private void requestPermissions() {
        ActivityCompat.requestPermissions(this,
                new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                MY_PERMISSION_REQUEST_FINE_LOCATION);
    }
    //Permissions not relevant for task2

    private void onRequestPermissionResult(int requestCode,String[] permissions,int[] grantResults){

        if (Build.VERSION.SDK_INT>=23 &&
                ContextCompat.checkSelfPermission(this,
                        Manifest.permission.ACCESS_FINE_LOCATION)==
                        PackageManager.PERMISSION_GRANTED){
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER,minTime,minDistance,this);
        }

    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }



    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onSupportNavigateUp() {
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main);
        return NavigationUI.navigateUp(navController, appBarConfiguration)
                || super.onSupportNavigateUp();
    }

    @Override
    public void onSensorChanged(SensorEvent sensorEvent) {
        float accX=sensorEvent.values[0];
        float accY=sensorEvent.values[0];
        float accZ=sensorEvent.values[0];

        tvX.setText(Float.toString(accX));
        tvY.setText(Float.toString(accX));
        tvZ.setText(Float.toString(accX));
    }


    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {

    }

    @Override
    public void onLocationChanged(@NonNull Location location) {
        double longitude=location.getLongitude();
        double latitude=location.getLatitude();

        tvLon.setText(Double.toString(longitude));
        tvLat.setText(Double.toString(latitude));
    }
}