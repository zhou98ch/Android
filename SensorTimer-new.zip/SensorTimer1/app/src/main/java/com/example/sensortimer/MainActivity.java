package com.example.sensortimer;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.AlertDialog;
import android.app.Service;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity implements SensorEventListener {

    TextView lightTextView;
    TextView tvX, tvY, tvZ;
    SensorManager sensorManager;
    Sensor lightSensor, acceSensor;

    public float lightVal = 0;
    public float acceX, acceY, acceZ = 0;

    public Intent intent ;
/*
    public double lat, lon = 0;
    static private final int MY_PERMISSION_REQUEST_FINE_LOCATION = 1;
    private LocationManager locationManager;
    private TextView tvLon, tvLat;
    //ms
    static private final long minTime = 1000;
    //m
    static private final float minDistance = 10;


 */
    ////////////
    private ServiceConnection sc;
    private TimerService myAppService;
    public float newLight, newAcceX, newAcceY, newAcceZ, newlon, newlat;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        lightTextView = (TextView) findViewById(R.id.lightTextView);

        tvX = (TextView) findViewById(R.id.textViewX);
        tvY = (TextView) findViewById(R.id.textViewY);
        tvZ = (TextView) findViewById(R.id.textViewZ);
/*
        tvLon = findViewById(R.id.longitute);
        tvLat = findViewById(R.id.latitude);
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

 */
        //startService(new Intent(this, TimerService.class).putExtra("lightVal",lightVal));


        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);

        lightSensor = sensorManager.getDefaultSensor(Sensor.TYPE_LIGHT);
        sensorManager.registerListener(this, lightSensor, SensorManager.SENSOR_DELAY_NORMAL);

        acceSensor = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        sensorManager.registerListener(this, acceSensor, SensorManager.SENSOR_DELAY_NORMAL);


        //////////////////////

        sc = new ServiceConnection() {
            @Override
            public void onServiceDisconnected(ComponentName name) {

            }

            @Override
            public void onServiceConnected(ComponentName name, IBinder service) {
                TimerService.MyBinder mBinder = (TimerService.MyBinder) service;
                myAppService = mBinder.getService();

                Timer checkTokenTimer = new Timer();//
                PeriodTask1 periodTask1 = new PeriodTask1(myAppService);
                checkTokenTimer.schedule(periodTask1, 0, 3000);

                //newLight = myAppService.getLightValue();
                //lightTextView.setText(String.valueOf(newLight));
            }
        };


        Intent intent = new Intent(this, TimerService.class);
        startService(intent);
        bindService(intent, sc, Service.BIND_AUTO_CREATE);

        Intent intent1 = new Intent(this, TimerService.class);
        startService(intent1);
        bindService(intent1, sc, Service.BIND_AUTO_CREATE);


        ///////////////////////

    }
/*
    @Override
    protected void onStart() {
        super.onStart();
        if (!locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            enableLocationSettings();
        } else {

            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                // TODO: Consider calling
                //    ActivityCompat#requestPermissions
                // here to request the missing permissions, and then overriding
                //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                //                                          int[] grantResults)
                // to handle the case where the user grants the permission. See the documentation
                // for ActivityCompat#requestPermissions for more details.
                return;
            }
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, minTime, minDistance, this);
            }
        }

    private void enableLocationSettings() {
        new AlertDialog.Builder(this)
                .setTitle("Enable GPS")
                .setMessage("GPS currentlt disabled. Do you want to enable GPS?")
                .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Intent settingsIntent=new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                    }
                })
                .setNegativeButton(android.R.string.no,null)
                .setIcon(android.R.drawable.ic_dialog_alert)
                .show();
    }

 */
    //Permissions not relevant for task2


    public class PeriodTask1 extends TimerTask {
        public TimerService myAppService;

        public PeriodTask1(TimerService TimerServicee) {
            myAppService = TimerServicee;

        }

        public void run() {
            runOnUiThread(new Runnable() {

                @Override
                public void run() {
                    newLight = myAppService.getLightValue();
                    Log.d("light get from service", String.valueOf(newLight));
                    lightTextView.setText("light:" + String.valueOf(newLight));

                    newAcceX = myAppService.getAcceXValue();
                    newAcceY = myAppService.getAcceYValue();
                    newAcceZ = myAppService.getAcceZValue();

                    Log.d("acceX get from service", String.valueOf(newAcceX));
                    Log.e("acceY get from service", String.valueOf(newAcceY));
                    Log.e("acceZ get from service", String.valueOf(newAcceZ));

                    tvX.setText("acceX:" + String.valueOf(newAcceX));

                    tvY.setText("acceY:" + String.valueOf(newAcceY));

                    tvZ.setText("acceZ:" + String.valueOf(newAcceZ));

/*
                    newlat = myAppService.getLatValue();
                    newlon = myAppService.getLonValue();
                    Log.e("Lat get from service", String.valueOf(newlat));
                    Log.e("Lon get from service", String.valueOf(newlon));
                    tvLon.setText("lon:" + String.valueOf(newlon));
                    tvLat.setText("lat:" + String.valueOf(newlat));

 */
                }

            });
        }
    }

    public void startChecking(View view) {

    }


    @Override
    protected void onResume() {
        super.onResume();
        sensorManager.registerListener(this, lightSensor, SensorManager.SENSOR_DELAY_NORMAL);
        sensorManager.registerListener(this, acceSensor, SensorManager.SENSOR_DELAY_NORMAL);

    }

    @Override
    public void onSensorChanged(SensorEvent sensorEvent) {

        //lightTextView.setText("000");
        if (sensorEvent.sensor.getType() == Sensor.TYPE_LIGHT) {
            //lightTextView.setText("lIGHT:"+sensorEvent.values[0]);
            lightVal = sensorEvent.values[0];
            //Log.d("change light:", String.valueOf(sensorEvent.values[0]));
            intent = new Intent(this, TimerService.class);
            intent.putExtra("lightVal", lightVal);
            startService(intent);
        }

         if (sensorEvent.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
             //lightTextView.setText("lIGHT:"+sensorEvent.values[0]);
             acceX = sensorEvent.values[0];
             acceY = sensorEvent.values[2];
             acceZ = sensorEvent.values[1];


           /*
            Log.d("change Xaccelerometer:", String.valueOf(sensorEvent.values[0]));
            Log.d("change Yaccelerometer:", String.valueOf(sensorEvent.values[1]));
            Log.d("change Zaccelerometer:", String.valueOf(sensorEvent.values[2]));
           */
             intent = new Intent(this, TimerService.class);
             intent.putExtra("acceX", acceX);
             intent.putExtra("acceY", acceY);
             intent.putExtra("acceZ", acceZ);
             startService(intent);
         }




    }
/*
    @Override
    public void onLocationChanged(@NonNull Location location) {
         lon=location.getLongitude();
         lat=location.getLatitude();

        intent = new Intent(this, TimerService.class);
        intent.putExtra("lon", lon);
        intent.putExtra("lat", lat);
        startService(intent);
    }

 */
    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {

    }


}