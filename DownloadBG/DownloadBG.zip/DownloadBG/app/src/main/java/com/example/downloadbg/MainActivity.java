package com.example.downloadbg;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {


    private static final String DOWNLOAD_URL = "https://cloudup.com/files/inYVmLryD4p/download";
    private static final int WRITE_EXTERNAL_STORAGE_REQUEST_CODE = 54654;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //DownloadSongService ds = new DownloadSongService(this);
    }

    public void startDownloading(View view){
        startService(DownloadSongService.getDownloadService(this, DOWNLOAD_URL, ""));
    }
}