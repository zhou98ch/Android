package com.example.sensortimer;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Service;
import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.os.IBinder;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity implements SensorEventListener{

    TextView lightTextView;
    TextView tvX,tvY,tvZ;
    SensorManager sensorManager;
    Sensor lightSensor,acceSensor;

    public float lightVal = 0;
    public float acceX,acceY,acceZ = 0;
    public Intent intent,intent1,intent2;

    private boolean sensorListenerRegistered=false;


    ////////////
    private ServiceConnection sc;
    private TimerService myAppService;
    public float newLight,newAcceX,newAcceY,newAcceZ;





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        lightTextView = (TextView) findViewById(R.id.lightTextView);

        tvX=(TextView) findViewById(R.id.textViewX);
        tvY=(TextView) findViewById(R.id.textViewY);
        tvZ=(TextView) findViewById(R.id.textViewZ);



        //startService(new Intent(this, TimerService.class).putExtra("lightVal",lightVal));


        sensorManager=(SensorManager)getSystemService(SENSOR_SERVICE);

        lightSensor=sensorManager.getDefaultSensor(Sensor.TYPE_LIGHT);
        sensorManager.registerListener(this,lightSensor, SensorManager.SENSOR_DELAY_NORMAL);

        acceSensor=sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        sensorManager.registerListener(this,acceSensor, SensorManager.SENSOR_DELAY_NORMAL);

        //////////////////////


        sc = new ServiceConnection() {
            @Override
            public void onServiceDisconnected(ComponentName name) {

            }

            @Override
            public void onServiceConnected(ComponentName name, IBinder service) {
                TimerService.MyBinder mBinder = (TimerService.MyBinder) service;
                myAppService = mBinder.getService();

                Timer checkTokenTimer = new Timer();//
                PeriodTask1 periodTask1 = new PeriodTask1(myAppService);
                checkTokenTimer.schedule(periodTask1, 0, 3000);

                //newLight = myAppService.getLightValue();
                //lightTextView.setText(String.valueOf(newLight));
            }
        };



        Intent intent = new Intent(this, TimerService.class);
        startService(intent);
        bindService(intent, sc, Service.BIND_AUTO_CREATE);


        ///////////////////////

    }
    public class PeriodTask1 extends TimerTask {
        public TimerService myAppService;

        public PeriodTask1(TimerService TimerServicee) {
            myAppService = TimerServicee;

        }

        public void run() {
            runOnUiThread(new Runnable() {

                @Override
                public void run() {
                    newLight = myAppService.getLightValue();
                    Log.d("light get from service", String.valueOf(newLight));
                    //TextView tv = (TextView) findViewById(R.id.lightTextView);
                    lightTextView.setText("light:"+String.valueOf(newLight));

                    newAcceX = myAppService.getAcceXValue();
                    newAcceY = myAppService.getAcceYValue();
                    newAcceZ = myAppService.getAcceZValue();

                    Log.d("acce_X get from service", String.valueOf(newAcceX));
                    //Log.e("new acceY", String.valueOf(newAcceY));
                    //Log.e("new acceZ", String.valueOf(newAcceZ));
                    //TextView tvX = (TextView) findViewById(R.id.textViewX);
                    tvX.setText("acceX:"+String.valueOf(newAcceX));

                    //TextView tvY = (TextView) findViewById(R.id.textViewY);
                    tvY.setText("acceY:"+String.valueOf(newAcceY));

                    //TextView tvZ = (TextView) findViewById(R.id.textViewZ);
                    tvZ.setText("acceZ:"+String.valueOf(newAcceZ));
                }




            });
        }
    }

    public void startChecking(View view){

    }

    @Override
    protected void onResume() {
        super.onResume();
        sensorManager.registerListener(this,lightSensor, SensorManager.SENSOR_DELAY_NORMAL);
        sensorManager.registerListener(this,acceSensor, SensorManager.SENSOR_DELAY_NORMAL);
    }

    @Override
    public void onSensorChanged(SensorEvent sensorEvent) {

        //lightTextView.setText("000");
        if (sensorEvent.sensor.getType() == Sensor.TYPE_LIGHT){
            //lightTextView.setText("lIGHT:"+sensorEvent.values[0]);
            lightVal = sensorEvent.values[0];
            //Log.d("change light:", String.valueOf(sensorEvent.values[0]));
            intent = new Intent(this, TimerService.class);
            intent.putExtra("lightVal",lightVal);
            startService(intent);

        }

        if (sensorEvent.sensor.getType() == Sensor.TYPE_ACCELEROMETER){
            //lightTextView.setText("lIGHT:"+sensorEvent.values[0]);
            acceX = sensorEvent.values[0];
            acceX = sensorEvent.values[1];
            acceX = sensorEvent.values[2];
            /*
            Log.d("change Xaccelerometer:", String.valueOf(sensorEvent.values[0]));
            Log.d("change Yaccelerometer:", String.valueOf(sensorEvent.values[1]));
            Log.d("change Zaccelerometer:", String.valueOf(sensorEvent.values[2]));

             */

            intent = new Intent(this, TimerService.class);
            intent = new Intent(this, TimerService.class);
            intent = new Intent(this, TimerService.class);
            intent.putExtra("acceX",acceX);
            intent.putExtra("acceY",acceY);
            intent.putExtra("acceZ",acceZ);
            startService(intent);


        }

    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {

    }


}