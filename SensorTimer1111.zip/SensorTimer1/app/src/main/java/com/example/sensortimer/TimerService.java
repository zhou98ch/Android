package com.example.sensortimer;

import android.app.IntentService;
import android.app.Service;
import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Binder;
import android.os.IBinder;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.Nullable;

import java.util.Timer;
import java.util.TimerTask;

 /*
public class TimerService extends Service  {

    private int InTime = 1 * 1000;
    private int periodTime = 3 * 1000;

    //SensorEvent sensorEvent;

    @Override
    public IBinder onBind(Intent arg0) {//这是Service必须要实现的方法，目前这里面什么都没有做

        return null;
    }

    @Override
    public void onCreate() {  //在onCreate()方法中打印了一个log便于测试
        super.onCreate();

        Timer checkTokenTimer = new Timer();//
        PeriodTask periodTask = new PeriodTask();
        checkTokenTimer.schedule(periodTask, InTime, periodTime);

    }

    public class PeriodTask extends TimerTask {
        public void run() {
            long time=System.currentTimeMillis();

            Log.e("time", "current second"+String.valueOf(time/1000));

        }

    }

    */

public class TimerService  extends IntentService{
    private int InTime = 1 * 1000;
    private int periodTime = 3 * 1000;

    public float lightValue = 10;
    public float acceX,acceY,acceZ = -1;

    public Intent intent;

    public float getLightValue() {
        return lightValue;
    }

    public float getAcceXValue() {
        return acceX;
    }

    public float getAcceYValue() {
        return acceY;
    }

    public float getAcceZValue() {
        return acceZ;
    }

    public TimerService() {
        super("TimerService");
    }
    @Override
    public void onCreate() {  //在onCreate()方法中打印了一个log便于测试
        super.onCreate();

        Timer checkTokenTimer = new Timer();//
        PeriodTask periodTask = new PeriodTask();
        checkTokenTimer.schedule(periodTask, InTime, periodTime);

    }

    @Override
    public int onStartCommand(@Nullable Intent intent, int flags, int startId) {

        //Log.e("etset","esgeh");
        lightValue = intent.getFloatExtra("lightVal",10);
        acceX=intent.getFloatExtra("acceX",-1);
        acceY=intent.getFloatExtra("acceY",-1);
        acceZ=intent.getFloatExtra("acceZ",-1);
        //Log.e("get_light", "every 3 seconds"+String.valueOf(lightValue));

        return START_STICKY;

    }

    @Override
    protected void onHandleIntent(Intent intent) {
        /*
        lightValue = intent.getFloatExtra("lightVal",-1);
        Log.e("etset","esgeh");
        Log.e("get LIGHT!!!!!", String.valueOf(lightValue));
        */
    }

    public class PeriodTask extends TimerTask {
        public void run() {
            long time=System.currentTimeMillis();

            //Log.e("time", "current timestamp in second"+String.valueOf(time/1000));
            Log.e("LIGHT!!!!!", String.valueOf(lightValue)+",current timestamp every 3 secons"+String.valueOf(time/1000));
            Log.e("ACCELARATOR_X!!!!!", String.valueOf(acceX)+",current timestamp every 3 secons"+String.valueOf(time/1000));
        }
    }
    //////////////////////////////////

    @Override
    public IBinder onBind(Intent intent) {
        //Log.d("onBind", "======");
        return new MyBinder();
    }

    public class MyBinder extends Binder {
        public TimerService getService() {
            //Log.d("getService", "====");
            return TimerService.this;
        }
    }

    @Override
    public void onDestroy() {
        //Log.d("MyAppService", "onDestroy");
        super.onDestroy();
    }

    @Override
    public boolean onUnbind(Intent intent) {
        //Log.d("MyAppService", "onUnbind");
        return super.onUnbind(intent);
    }



}