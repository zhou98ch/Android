package com.example.mycalculator;


import android.os.Bundle;

import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;


public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    //creat view objects
    Button numberzero,numberone,numbertwo,numberthree,numberfour,numberfive,numbersix,numberseven,numbereight,numbernine,spot;
    Button mul,div,plus,min;
    Button cls,equal;
    EditText result;
    boolean clr_flag; //clear

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //get view objects
        //setContentView(R.layout.activity_main);
        numberzero= (Button) findViewById(R.id.zero);
        numberone= (Button) findViewById(R.id.one);
        numbertwo= (Button) findViewById(R.id.two);
        numberthree= (Button) findViewById(R.id.three);
        numberfour= (Button) findViewById(R.id.four);
        numberfive= (Button) findViewById(R.id.five);
        numbersix= (Button) findViewById(R.id.six);
        numberseven= (Button) findViewById(R.id.seven);
        numbereight= (Button) findViewById(R.id.eight);
        numbernine= (Button) findViewById(R.id.nine);
        spot= (Button) findViewById(R.id.spot);
        plus= (Button) findViewById(R.id.plus);
        min= (Button) findViewById(R.id.min);
        mul= (Button) findViewById(R.id.mul);
        div= (Button) findViewById(R.id.div);
        cls= (Button) findViewById(R.id.cls);
        equal= (Button) findViewById(R.id.equal);
        result= (EditText) findViewById(R.id.result);

        //set click listener
        numberzero.setOnClickListener(this);
        numberone.setOnClickListener(this);
        numbertwo.setOnClickListener(this);
        numberthree.setOnClickListener(this);
        numberfour.setOnClickListener(this);
        numberfive.setOnClickListener(this);
        numbersix.setOnClickListener(this);
        numberseven.setOnClickListener(this);
        numbereight.setOnClickListener(this);
        numbernine.setOnClickListener(this);
        spot.setOnClickListener(this);
        plus.setOnClickListener(this);
        min.setOnClickListener(this);
        mul.setOnClickListener(this);
        div.setOnClickListener(this);
        cls.setOnClickListener(this);
        equal.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        String str=result.getText().toString();//get the previous text of result
        switch (v.getId()){
            case   R.id.zero:
            case   R.id.one:
            case   R.id.two:
            case   R.id.three:
            case   R.id.four:
            case   R.id.five:
            case   R.id.six:
            case   R.id.seven:
            case   R.id.eight:
            case   R.id.nine:
            case   R.id.spot:
                //check clear flag
                if(clr_flag){
                    str="";
                    result.setText(""); //set result to empty
                    clr_flag=false; //turn off the clear flag
                }
                result.setText(str+((Button)v).getText());
                //new result = previous result + newly clicked button's value

                break;
            case R.id.plus:
            case R.id.min:
            case R.id.mul:
            case R.id.div:
                if(clr_flag){
                    clr_flag=false;
                    str="";
                    result.setText("");
                }

                //if operators are repeated
                if(str.contains("+")||str.contains("-")||str.contains("×")||str.contains("÷")) {
                    //get the number before the previous operation
                    // (previous str = "1 +",input "-", new str = "1"
                    str=str.substring(0,str.indexOf(" "));
                }
                //set text to "1 - "
                result.setText(str+" "+((Button)v).getText()+" ");
                break;
            case R.id.cls:
                if(clr_flag)
                    clr_flag=false;
                str="";
                result.setText("");
                break;
            case R.id.equal: //make calculation
                getResult();
                break;
        }
    }

    private void getResult() {
        String exp=result.getText().toString();
        if(exp==null||exp.equals("")) return ;

        if(!exp.contains(" ")){
            return ;
        }
        if(clr_flag){
            clr_flag=false;
            return;
        }
        clr_flag=true; //after showing the calculation result, if another input come in, clear the result field
        //get operator number1
        String number1=exp.substring(0,exp.indexOf(" "));
        //get operator
        String operator=exp.substring(exp.indexOf(" ")+1,exp.indexOf(" ")+2);
        //get operator number1
        String number2=exp.substring(exp.indexOf(" ")+3);
        double cnt=0;
        if(!number1.equals("")&&!number2.equals("")){
            double d1=Double.parseDouble(number1);
            double d2=Double.parseDouble(number2);
            if(operator.equals("+")){
                cnt=d1+d2;
            }
            if(operator.equals("-")){
                cnt=d1-d2;
            }
            if(operator.equals("×")){
                cnt=d1*d2;
            }
            if(operator.equals("÷")){
                if(d2==0) cnt=0;
                else cnt=d1/d2;
            }
            result.setText(cnt+"");

        }
        //if s1 is not empty, s2 is empty
        else if(!number1.equals("")&&number2.equals("")){
            double d1=Double.parseDouble(number1);
            if(operator.equals("+")){
                cnt=d1;
            }
            if(operator.equals("-")){
                cnt=d1;
            }
            if(operator.equals("×")){
                cnt=0;
            }
            if(operator.equals("÷")){
                cnt=0;
            }

            result.setText(cnt+"");
        }
        //if s1 is empty, s2 not empty
        else if(number1.equals("")&&!number2.equals("")){
            double d2=Double.parseDouble(number2);
            if(operator.equals("+")){
                cnt=d2;
            }
            if(operator.equals("-")){
                cnt=0-d2;
            }
            if(operator.equals("×")){
                cnt=0;
            }
            if(operator.equals("÷")){
                cnt=0;
            }

            result.setText(cnt+"");
        }
        else {
            result.setText("");
        }
    }
}